﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Timers;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Media;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Wpf.Ui.Controls;
using Skibidi;

namespace WpfApp1
{
    public partial class MainWindow : FluentWindow
    {
        private static string robloxProcessName = "RobloxPlayerBeta";
        private static string liveChannelUrl = "https://clientsettings.roblox.com/v2/client-version/WindowsPlayer/channel/live";
        private static string clientVersionUpload;
        private System.Timers.Timer _timer;
        private bool _isInjected;



        public MainWindow()
        {
            MainWindow.clientVersionUpload = MainWindow.GetCurrentVersion();
            InitializeComponent();
            InitializeWebView();
            StartMonitoring();
            Status.Fill = (SolidColorBrush)new BrushConverter().ConvertFromString("#FFFF7F7F");

            Closing += ClosingEvent;
        }

        private void StartMonitoring()
        {
            _timer = new System.Timers.Timer(5000);
            _timer.Elapsed += CheckRobloxStatus;
            _timer.AutoReset = true;
            _timer.Start();
        }

        private void TerminateNode()
        {
            try
            {
                foreach (Process process in Process.GetProcessesByName("node"))
                {
                    process.Kill();
                    process.WaitForExit();
                }
            }
            catch (Exception) { }
        }

        private void ClosingEvent(object sender, CancelEventArgs e)
        {
            if (global::System.Windows.Forms.MessageBox.Show("Are you sure you want to close Zorara?", "Exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == global::System.Windows.Forms.DialogResult.Yes)
            {
                TerminateNode();
                return;
            }
            e.Cancel = true;
        }

        private static Process GetRobloxProcess()
        {
            Process[] processesByName = Process.GetProcessesByName(MainWindow.robloxProcessName);
            return processesByName.Length > 0 ? processesByName[0] : null;
        }

        private static string GetCurrentVersion()
        {
            string text;
            using (HttpClient httpClient = new HttpClient())
            {
                text = JObject.Parse(httpClient.GetStringAsync(MainWindow.liveChannelUrl).Result)["clientVersionUpload"].ToString();
            }
            return text;
        }

        private static void LaunchRobloxWithArgs(string exePath)
        {
            string text = "--app -isInstallerLaunch --launchtime=" + DateTimeOffset.Now.ToUnixTimeMilliseconds().ToString() + " -channel production";
            Process.Start(exePath, text).WaitForExit();
        }

        private void CheckRobloxStatus(object sender, ElapsedEventArgs e)
        {
            bool isRobloxRunning = IsRobloxRunning();

            Dispatcher.Invoke(() =>
            {
                if (_isInjected)
                {
                    return;
                }

                if (!isRobloxRunning)
                {
                    _isInjected = false;
                    Status.Fill = (SolidColorBrush)new BrushConverter().ConvertFromString("#FFFF7F7F");
                }
                else
                {
                    Status.Fill = (SolidColorBrush)new BrushConverter().ConvertFromString("#e69138");
                }
            });
        }

        private bool IsRobloxRunning()
        {
            Process[] processes = Process.GetProcessesByName("RobloxPlayerBeta");
            return processes.Length > 0;
        }

        private async void InitializeWebView()
        {
            try
            {
                await CodeEditor.EnsureCoreWebView2Async(null);
            }
            catch (Exception ex)
            {
                global::System.Windows.MessageBox.Show("WebView2 initialization failed: " + ex.Message, "Initialization Error", global::System.Windows.MessageBoxButton.OK, MessageBoxImage.Hand);
            }
        }

        private void fluentWindow_Loaded(object sender, RoutedEventArgs e)
        {
            CodeEditor.Source = new Uri(global::System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Monaco\\index.html"));
        }

        private async void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            await CodeEditor.ExecuteScriptAsync("editor.setValue('')");
        }

        private async void InjectButton_MouseClick1(object sender, RoutedEventArgs e)
        {
            string tempPath = System.IO.Path.GetTempPath();
            string celeryFolderPath = System.IO.Path.Combine(tempPath, "celery");
            System.IO.Directory.CreateDirectory(celeryFolderPath);
            string filePath = System.IO.Path.Combine(celeryFolderPath, "myfile.txt");
            if (!System.IO.File.Exists(filePath))
            {
                System.IO.File.Create(filePath).Dispose();
            }

            Skibidi.BitdancersDrug.attach();

            Status.Fill = Brushes.Green;
        }

        private async void ExecuteClicked(object sender, RoutedEventArgs e)
        {
            Skibidi.BitdancersDrug.execute(MainWindow.ReplaceSpecialCharactersWithUnicode(JsonConvert.DeserializeObject<string>(await CodeEditor.ExecuteScriptAsync("GetText()"))));
        }

        private static string ReplaceSpecialCharactersWithUnicode(string input)
        {
            string text = "[^\\u0000-\\u007F]";
            return Regex.Replace(input, text, (Match m) => "\\u{" + MainWindow.GetUnicodeEscape((int)m.Value[0]) + "}");
        }

        private static string GetUnicodeEscape(int codePoint)
        {
            return string.Format("{0:x4}", codePoint);
        }

        private async void OpenFile(object sender, RoutedEventArgs e)
        {
            string text = global::System.IO.Path.Combine(global::System.IO.Path.GetTempPath(), "Solara.Dir", "bin", "path.txt");
            if (File.Exists(text))
            {
                string text2 = global::System.IO.Path.Combine(global::System.IO.Path.GetFullPath(File.ReadAllText(text)), "scripts");
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Title = "Open Script";
                openFileDialog.InitialDirectory = text2;
                if (openFileDialog.ShowDialog() == global::System.Windows.Forms.DialogResult.OK)
                {
                    string text3 = File.ReadAllText(openFileDialog.FileName);
                    await CodeEditor.ExecuteScriptAsync("editor.setValue(" + text3 + ")");
                }
                GC.Collect();
            }
        }

        private async void SaveFile(object sender, RoutedEventArgs e)
        {
            string text = global::System.IO.Path.Combine(global::System.IO.Path.GetTempPath(), "Solara.Dir", "bin", "path.txt");
            if (!File.Exists(text))
            {
                Console.WriteLine("Error: path.txt file not found.");
            }
            else
            {
                string text2 = global::System.IO.Path.Combine(global::System.IO.Path.GetFullPath(File.ReadAllText(text)), "scripts");
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.InitialDirectory = text2;
                saveFileDialog.Title = "Save Script";
                if (saveFileDialog.ShowDialog() == global::System.Windows.Forms.DialogResult.OK)
                {
                    string fileName = global::System.IO.Path.GetFileName(saveFileDialog.FileName);
                    string filePath = global::System.IO.Path.Combine(text2, fileName);
                    string text3 = await CodeEditor.ExecuteScriptAsync("GetText()");
                    File.WriteAllText(filePath, text3);
                    filePath = null;
                }
                GC.Collect();
            }
        }

        private void TextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {

        }
    }
}
