﻿using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Windows;

namespace XamlGeneratedNamespace
{
	public class GeneratedApplication : Application
	{
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (this._contentLoaded)
			{
				return;
			}
			this._contentLoaded = true;
			base.StartupUri = new Uri("MainWindow.xaml", UriKind.Relative);
			Uri uri = new Uri("/WpfApp1;component/app.xaml", UriKind.Relative);
			Application.LoadComponent(this, uri);
		}

		[STAThread]
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public static void Main()
		{
			GeneratedApplication generatedApplication = new GeneratedApplication();
			generatedApplication.InitializeComponent();
			generatedApplication.Run();
		}

		private bool _contentLoaded;
	}
}
