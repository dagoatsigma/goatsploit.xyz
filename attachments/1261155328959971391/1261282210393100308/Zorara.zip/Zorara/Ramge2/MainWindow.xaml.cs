﻿using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Xml;
using ICSharpCode.AvalonEdit.Highlighting;
using ICSharpCode.AvalonEdit.Highlighting.Xshd;

using Skibidi;

namespace Ramge
{
    public partial class MainWindow : Window
    {
        private static readonly HttpClient client = new HttpClient();

        public MainWindow()
        {
            InitializeComponent();
            Stream stream = File.OpenRead("./syntax/lua.xshd");
            XmlReader reader = new XmlTextReader(stream);
            ScriptHolder.SyntaxHighlighting = HighlightingLoader.Load(reader, HighlightingManager.Instance);
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Minimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            SettingsWindow settingsWindow = new SettingsWindow(this);
            settingsWindow.Owner = this;
            settingsWindow.Show();
        }

        private void Attach_Click(object sender, RoutedEventArgs e)
        {
            string tempPath = System.IO.Path.GetTempPath();
            string celeryFolderPath = System.IO.Path.Combine(tempPath, "celery");
            System.IO.Directory.CreateDirectory(celeryFolderPath);
            string filePath = System.IO.Path.Combine(celeryFolderPath, "myfile.txt");
            if (!System.IO.File.Exists(filePath))
            {
                System.IO.File.Create(filePath).Dispose();
            }

            Skibidi.BitdancersDrug.attach();
        }

        private void label_MouseMove(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        private void Execute_Click(object sender, RoutedEventArgs e)
        {
            Skibidi.BitdancersDrug.execute(ScriptHolder.Text);
        }
    }
}