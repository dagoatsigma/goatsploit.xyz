﻿using ICSharpCode.AvalonEdit;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Ramge
{
    public partial class SettingsWindow : Window
    {
        private MainWindow _mainWindow;

        public SettingsWindow(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
            TopMostCheckBox.IsChecked = _mainWindow.Topmost;
            _mainWindow.Topmost = false; // Disable Topmost for main window when settings window is open

            // Set initial values for theme and transparency
            TransparencySlider.Value = _mainWindow.Opacity;
        }

        private void TopMostCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            _mainWindow.Topmost = true;
        }

        private void TopMostCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            _mainWindow.Topmost = false;
        }



        private void TransparencySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (_mainWindow != null)
            {
                _mainWindow.Opacity = TransparencySlider.Value;
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            // Restore Topmost status based on the checkbox when settings window is closed
            _mainWindow.Topmost = TopMostCheckBox.IsChecked == true;
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

    }
}
