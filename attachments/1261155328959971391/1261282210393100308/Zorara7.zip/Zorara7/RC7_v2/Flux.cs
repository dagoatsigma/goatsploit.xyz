using System;

namespace RC7_v2;

internal class Flux
{
	public bool DoAutoAttach { get; internal set; }

	internal void Execute(string text)
	{
		throw new NotImplementedException();
	}

	internal void InitializeAPI()
	{
		throw new NotImplementedException();
	}

	internal void inject()
	{
		throw new NotImplementedException();
	}
}
