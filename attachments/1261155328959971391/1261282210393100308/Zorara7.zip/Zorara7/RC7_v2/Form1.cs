using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using FastColoredTextBoxNS;
using Skibidi;

namespace RC7_v2;

public class Form1 : Form
{
	private protected readonly Flux Fluxus = new Flux();

	private IContainer components = null;

	private RichTextBox richTextBox1;

	private FastColoredTextBox fastColoredTextBox1;

	private MenuStrip menuStrip1;

	private ToolStripMenuItem aboutToolStripMenuItem;

	private ToolStripMenuItem madeByKkggssToolStripMenuItem;

	private ToolStripMenuItem commandsToolStripMenuItem;

	private ToolStripMenuItem robloxToolStripMenuItem;

	private ToolStripMenuItem discordToolStripMenuItem;

	private ToolStripMenuItem aboutToolStripMenuItem1;

	private Button button1;

	private Button button2;

	private Button button3;

	private Button button5;

	private Button button4;

	private Button button6;

	private Button button7;

	private Button button8;

	private Button button9;

	private OpenFileDialog openFileDialog1;

	private ToolStripMenuItem flyToolStripMenuItem;

	private ToolStripMenuItem killToolStripMenuItem;

	private ToolStripMenuItem rEloadToolStripMenuItem;

	private ToolStripMenuItem madeByKkggssToolStripMenuItem1;

	public Form1()
	{
		InitializeComponent();
	}

	private void fastColoredTextBox1_Load(object sender, EventArgs e)
	{
	}

	private void madeByKkggssToolStripMenuItem_Click(object sender, EventArgs e)
    {
        string tempPath = System.IO.Path.GetTempPath();
        string celeryFolderPath = System.IO.Path.Combine(tempPath, "celery");
        System.IO.Directory.CreateDirectory(celeryFolderPath);
        string filePath = System.IO.Path.Combine(celeryFolderPath, "myfile.txt");
        if (!System.IO.File.Exists(filePath))
        {
            System.IO.File.Create(filePath).Dispose();
        }

        Skibidi.BitdancersDrug.attach();
    }

    private void discordToolStripMenuItem_Click(object sender, EventArgs e)
	{
		// soon to add
	}

	private void button5_Click(object sender, EventArgs e)
	{
		SaveFileDialog saveFileDialog1 = new SaveFileDialog();
		if (saveFileDialog1.ShowDialog() != DialogResult.OK)
		{
			return;
		}
		using Stream s = File.Open(saveFileDialog1.FileName, FileMode.CreateNew);
		using StreamWriter sw = new StreamWriter(s);
		sw.Write(fastColoredTextBox1.Text);
	}

	private void button4_Click(object sender, EventArgs e)
	{

	}

	private void button6_Click(object sender, EventArgs e)
	{

	}

	private void button7_Click(object sender, EventArgs e)
	{

	}

	private void button8_Click(object sender, EventArgs e)
	{

	}

	private void button9_Click(object sender, EventArgs e)
	{
	}

	private void button3_Click(object sender, EventArgs e)
	{
		fastColoredTextBox1.Clear();
	}

	private void button2_Click(object sender, EventArgs e)
	{
        Skibidi.BitdancersDrug.execute(fastColoredTextBox1.Text);
    }

	private void button1_Click(object sender, EventArgs e)
	{
		OpenFileDialog openFileDialog1 = new OpenFileDialog();
		if (openFileDialog1.ShowDialog() == DialogResult.OK)
		{
			openFileDialog1.Title = "Open";
			fastColoredTextBox1.Text = File.ReadAllText(openFileDialog1.FileName);
		}
	}

	private void Form1_Load(object sender, EventArgs e)
	{
	}

	private void notDevelopedYetToolStripMenuItem_Click(object sender, EventArgs e)
	{
	}

	private void flyToolStripMenuItem_Click(object sender, EventArgs e)
	{
		Fluxus.DoAutoAttach = true;
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.components = new System.ComponentModel.Container();
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RC7_v2.Form1));
		this.richTextBox1 = new System.Windows.Forms.RichTextBox();
		this.fastColoredTextBox1 = new FastColoredTextBoxNS.FastColoredTextBox();
		this.menuStrip1 = new System.Windows.Forms.MenuStrip();
		this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.madeByKkggssToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.discordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.commandsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.flyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.robloxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.killToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.rEloadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
		this.aboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
		this.button1 = new System.Windows.Forms.Button();
		this.button2 = new System.Windows.Forms.Button();
		this.button3 = new System.Windows.Forms.Button();
		this.button5 = new System.Windows.Forms.Button();
		this.button4 = new System.Windows.Forms.Button();
		this.button6 = new System.Windows.Forms.Button();
		this.button7 = new System.Windows.Forms.Button();
		this.button8 = new System.Windows.Forms.Button();
		this.button9 = new System.Windows.Forms.Button();
		this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
		this.madeByKkggssToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
		((System.ComponentModel.ISupportInitialize)this.fastColoredTextBox1).BeginInit();
		this.menuStrip1.SuspendLayout();
		base.SuspendLayout();
		this.richTextBox1.Location = new System.Drawing.Point(12, 297);
		this.richTextBox1.Name = "richTextBox1";
		this.richTextBox1.Size = new System.Drawing.Size(268, 55);
		this.richTextBox1.TabIndex = 0;
		this.richTextBox1.Text = "";
		this.fastColoredTextBox1.AutoCompleteBracketsList = new char[10] { '(', ')', '{', '}', '[', ']', '"', '"', '\'', '\'' };
		this.fastColoredTextBox1.AutoIndentCharsPatterns = "^\\s*[\\w\\.]+(\\s\\w+)?\\s*(?<range>=)\\s*(?<range>[^;=]+);\r\n^\\s*(case|default)\\s*[^:]*(?<range>:)\\s*(?<range>[^;]+);";
		this.fastColoredTextBox1.AutoScrollMinSize = new System.Drawing.Size(27, 14);
		this.fastColoredTextBox1.BackBrush = null;
		this.fastColoredTextBox1.CharHeight = 14;
		this.fastColoredTextBox1.CharWidth = 8;
		this.fastColoredTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
		this.fastColoredTextBox1.DisabledColor = System.Drawing.Color.FromArgb(100, 180, 180, 180);
		this.fastColoredTextBox1.Font = new System.Drawing.Font("Courier New", 9.75f);
		this.fastColoredTextBox1.IsReplaceMode = false;
		this.fastColoredTextBox1.Location = new System.Drawing.Point(10, 37);
		this.fastColoredTextBox1.Name = "fastColoredTextBox1";
		this.fastColoredTextBox1.Paddings = new System.Windows.Forms.Padding(0);
		this.fastColoredTextBox1.SelectionColor = System.Drawing.Color.FromArgb(60, 0, 0, 255);
		this.fastColoredTextBox1.ServiceColors = (FastColoredTextBoxNS.ServiceColors)resources.GetObject("fastColoredTextBox1.ServiceColors");
		this.fastColoredTextBox1.Size = new System.Drawing.Size(288, 236);
		this.fastColoredTextBox1.TabIndex = 1;
		this.fastColoredTextBox1.Zoom = 100;
		this.fastColoredTextBox1.Load += new System.EventHandler(fastColoredTextBox1_Load);
		this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[4] { this.aboutToolStripMenuItem, this.commandsToolStripMenuItem, this.robloxToolStripMenuItem, this.aboutToolStripMenuItem1 });
		this.menuStrip1.Location = new System.Drawing.Point(0, 0);
		this.menuStrip1.Name = "menuStrip1";
		this.menuStrip1.Size = new System.Drawing.Size(340, 24);
		this.menuStrip1.TabIndex = 2;
		this.menuStrip1.Text = "menuStrip1";
		this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.madeByKkggssToolStripMenuItem, this.discordToolStripMenuItem });
		this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
		this.aboutToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
		this.aboutToolStripMenuItem.Text = "Settings";
		this.madeByKkggssToolStripMenuItem.Name = "madeByKkggssToolStripMenuItem";
		this.madeByKkggssToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
		this.madeByKkggssToolStripMenuItem.Text = "Attach";
		this.madeByKkggssToolStripMenuItem.Click += new System.EventHandler(madeByKkggssToolStripMenuItem_Click);
		this.discordToolStripMenuItem.Name = "discordToolStripMenuItem";
		this.discordToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
		this.discordToolStripMenuItem.Text = "Support";
		this.discordToolStripMenuItem.Click += new System.EventHandler(discordToolStripMenuItem_Click);
		this.commandsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.flyToolStripMenuItem });
		this.commandsToolStripMenuItem.Name = "commandsToolStripMenuItem";
		this.commandsToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
		this.commandsToolStripMenuItem.Text = "Commands";
		this.flyToolStripMenuItem.Name = "flyToolStripMenuItem";
		this.flyToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
		this.flyToolStripMenuItem.Text = "AutoAttach";
		this.flyToolStripMenuItem.Click += new System.EventHandler(flyToolStripMenuItem_Click);
		this.robloxToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.killToolStripMenuItem, this.rEloadToolStripMenuItem });
		this.robloxToolStripMenuItem.Name = "robloxToolStripMenuItem";
		this.robloxToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
		this.robloxToolStripMenuItem.Text = "Roblox";
		this.killToolStripMenuItem.Name = "killToolStripMenuItem";
		this.killToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
		this.killToolStripMenuItem.Text = "Kill";
		this.rEloadToolStripMenuItem.Name = "rEloadToolStripMenuItem";
		this.rEloadToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
		this.rEloadToolStripMenuItem.Text = "REload";
		this.aboutToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.madeByKkggssToolStripMenuItem1 });
		this.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1";
		this.aboutToolStripMenuItem1.Size = new System.Drawing.Size(52, 20);
		this.aboutToolStripMenuItem1.Text = "About";
		this.button1.BackColor = System.Drawing.Color.Transparent;
		this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
		this.button1.Location = new System.Drawing.Point(10, 273);
		this.button1.Name = "button1";
		this.button1.Size = new System.Drawing.Size(98, 26);
		this.button1.TabIndex = 3;
		this.button1.UseVisualStyleBackColor = false;
		this.button1.Click += new System.EventHandler(button1_Click);
		this.button2.BackColor = System.Drawing.Color.Transparent;
		this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
		this.button2.Location = new System.Drawing.Point(104, 273);
		this.button2.Name = "button2";
		this.button2.Size = new System.Drawing.Size(98, 26);
		this.button2.TabIndex = 4;
		this.button2.UseVisualStyleBackColor = false;
		this.button2.Click += new System.EventHandler(button2_Click);
		this.button3.BackColor = System.Drawing.Color.Transparent;
		this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
		this.button3.Location = new System.Drawing.Point(202, 273);
		this.button3.Name = "button3";
		this.button3.Size = new System.Drawing.Size(98, 26);
		this.button3.TabIndex = 5;
		this.button3.UseVisualStyleBackColor = false;
		this.button3.Click += new System.EventHandler(button3_Click);
		this.button5.BackColor = System.Drawing.Color.Transparent;
		this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
		this.button5.Location = new System.Drawing.Point(305, 136);
		this.button5.Name = "button5";
		this.button5.Size = new System.Drawing.Size(32, 31);
		this.button5.TabIndex = 7;
		this.button5.UseVisualStyleBackColor = false;
		this.button5.Click += new System.EventHandler(button5_Click);
		this.button4.BackColor = System.Drawing.Color.Transparent;
		this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
		this.button4.Location = new System.Drawing.Point(305, 173);
		this.button4.Name = "button4";
		this.button4.Size = new System.Drawing.Size(32, 31);
		this.button4.TabIndex = 8;
		this.button4.UseVisualStyleBackColor = false;
		this.button4.Click += new System.EventHandler(button4_Click);
		this.button6.BackColor = System.Drawing.Color.Transparent;
		this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
		this.button6.Location = new System.Drawing.Point(305, 210);
		this.button6.Name = "button6";
		this.button6.Size = new System.Drawing.Size(32, 31);
		this.button6.TabIndex = 9;
		this.button6.UseVisualStyleBackColor = false;
		this.button6.Click += new System.EventHandler(button6_Click);
		this.button7.BackColor = System.Drawing.Color.Transparent;
		this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
		this.button7.Location = new System.Drawing.Point(305, 247);
		this.button7.Name = "button7";
		this.button7.Size = new System.Drawing.Size(32, 31);
		this.button7.TabIndex = 10;
		this.button7.UseVisualStyleBackColor = false;
		this.button7.Click += new System.EventHandler(button7_Click);
		this.button8.BackColor = System.Drawing.Color.Transparent;
		this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
		this.button8.Location = new System.Drawing.Point(305, 284);
		this.button8.Name = "button8";
		this.button8.Size = new System.Drawing.Size(32, 31);
		this.button8.TabIndex = 11;
		this.button8.UseVisualStyleBackColor = false;
		this.button8.Click += new System.EventHandler(button8_Click);
		this.button9.BackColor = System.Drawing.Color.Transparent;
		this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
		this.button9.Location = new System.Drawing.Point(305, 321);
		this.button9.Name = "button9";
		this.button9.Size = new System.Drawing.Size(32, 31);
		this.button9.TabIndex = 12;
		this.button9.UseVisualStyleBackColor = false;
		this.button9.Click += new System.EventHandler(button9_Click);
		this.openFileDialog1.FileName = "openFileDialog1";
		this.madeByKkggssToolStripMenuItem1.Name = "Zorara7";
		this.madeByKkggssToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
		this.madeByKkggssToolStripMenuItem1.Text = "Zorara7";
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.BackgroundImage = (System.Drawing.Image)resources.GetObject("$this.BackgroundImage");
		base.ClientSize = new System.Drawing.Size(340, 354);
		base.Controls.Add(this.button9);
		base.Controls.Add(this.button8);
		base.Controls.Add(this.button7);
		base.Controls.Add(this.button6);
		base.Controls.Add(this.button4);
		base.Controls.Add(this.button5);
		base.Controls.Add(this.button3);
		base.Controls.Add(this.button2);
		base.Controls.Add(this.button1);
		base.Controls.Add(this.fastColoredTextBox1);
		base.Controls.Add(this.richTextBox1);
		base.Controls.Add(this.menuStrip1);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
		base.MainMenuStrip = this.menuStrip1;
		base.MaximizeBox = false;
		base.Name = "Form1";
		this.RightToLeft = System.Windows.Forms.RightToLeft.No;
		base.ShowIcon = false;
		this.Text = "Zorara7";
		base.TopMost = true;
		base.Load += new System.EventHandler(Form1_Load);
		((System.ComponentModel.ISupportInitialize)this.fastColoredTextBox1).EndInit();
		this.menuStrip1.ResumeLayout(false);
		this.menuStrip1.PerformLayout();
		base.ResumeLayout(false);
		base.PerformLayout();
	}
}
